# UI v1.2.1 검증 — 2026-10-11

## 도구와 결과
- 컴파일: Microsoft .NET SDK 8.0.425 Roslyn / Microsoft.NETFramework.ReferenceAssemblies.net48 1.0.3
- SDK SHA512는 v1.2에 보존된 Microsoft 게시자 값과 일치.
- 대상: net48 / x64 / optimize+ / C# 5, 제공 PNG embedded resource 포함.
- 결과: RELEASE_BUILD_UI.txt (오류 없음).
- Linux Mono 6.8 + Xvfb의 WinForms 호환 렌더러에서 창 크기 변경, 긴 CPU 이름, 모델 경로, 설정 탭 및 안내 창을 검사.
- 확대 검사는 컨트롤과 글꼴을 125%, 150%, 200%로 키운 모의 검사. Windows의 DPI 변경 이벤트 검증과 구별.
- UI_LAYOUT_MONO.txt: LAYOUT_ISSUES=0. 실제 렌더링에서 기본/축소 화면, 안내 팝업, 확대 글꼴 확인.
- Windows 자체 실행, 디스플레이 배율/모니터 이동, 추론: 미실행.

## 유지 범위 확인
Core.cs / Library.cs / WindowsHost.cs의 SHA256은 원래 v1.2 파일과 동일.
설정 키, 실행기 선택, 모델 자동 검색, 서버 시작/중지의 기존 흐름 유지.
새 모델 다운로드나 외부 통신 기능을 추가하지 않음.
로고는 사용자가 제공한 image(4).png 원본 바이트를 내장. 별도 로고 파일 없이 EXE에서 표시.

## 재빌드
Windows의 승인된 .NET Framework 4.8/Visual Studio 환경에서 Build.cmd 또는 기존 솔루션을 사용.
직원 배포본에는 빌드한 EXE가 들어 있으므로 최초 실행 빌드가 필요하지 않음.

## 설계 참고
https://learn.microsoft.com/en-us/dotnet/desktop/winforms/high-dpi-support-in-windows-forms
https://learn.microsoft.com/en-us/dotnet/desktop/winforms/controls/autosize-behavior-in-the-tablelayoutpanel-control
